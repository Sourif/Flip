# Change to the directory where SoundVolumeView.exe is located
$target = "$env:USERPROFILE\Documents\Virtual Machines\Ubuntu24\"
cd $target

# Enable the playback device named "Speakers"
.\SoundVolumeView.exe /Enable "Speakers"

# Set it as the default playback device
.\SoundVolumeView.exe /SetDefault "Speakers" 1
