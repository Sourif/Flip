$StartupPath = [Environment]::GetFolderPath('Startup')
$ShortcutPath = "$StartupPath\WindowsStartupSystem.lnk"
$TargetPath = "$env:USERPROFILE\Documents\Virtual Machines\Ubuntu24\launcher.exe"

$WshShell = New-Object -ComObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut($ShortcutPath)
$Shortcut.TargetPath = $TargetPath
$Shortcut.Save()