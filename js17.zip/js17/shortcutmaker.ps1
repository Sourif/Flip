$StartupPath = [Environment]::GetFolderPath('Startup')
$ShortcutPath = "$StartupPath\StartupSystem.lnk"
$TargetPath = "$env:USERPROFILE\Documents\Virtual Machines\Ubuntu24\StartupSystem.exe"

$WshShell = New-Object -ComObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut($ShortcutPath)
$Shortcut.TargetPath = $TargetPath
$Shortcut.Save()