# ubuntu24.ps1
param(
    [string]$SoundName = "ALT.WAV"  # Default sound name
)


#############################################################################################################################################

# Function to maintain volume at specific level in a separate job
function Keep-Volume-At-Level {
    param (
        [int]$volumeLevel = 50  # Default value if not specified
    )

    $job = Start-Job -ScriptBlock {
        param($level)
        $wshShell = New-Object -ComObject WScript.Shell
        $keyPresses = [Math]::Ceiling($level / 2)

        while ($true) {

            # Set to desired level
            for ($i = 0; $i -lt $keyPresses; $i++) {
                $wshShell.SendKeys([char]175)
            }
            Write-Host "Essai son"

            # Check every second
            Start-Sleep -Milliseconds 100
        }
    } -ArgumentList $volumeLevel

    return $job
}


function Start-Mouse-Movement {
    $job = Start-Job {
        Add-Type -AssemblyName System.Windows.Forms
        Add-Type -AssemblyName System.Drawing
        while ($true) {
            [System.Windows.Forms.Cursor]::Position = New-Object System.Drawing.Point(500, 300)
            Start-Sleep -Milliseconds 100
        }
    }
    return $job
}

#############################################################################################################################################

# Set Close Lid to "Do Nothing"
powercfg -setacvalueindex SCHEME_CURRENT 4f971e89-eebd-4455-a8de-9e59040e7347 5ca83367-6e45-459f-a27b-476b1d01c936 0
powercfg -setdcvalueindex SCHEME_CURRENT 4f971e89-eebd-4455-a8de-9e59040e7347 5ca83367-6e45-459f-a27b-476b1d01c936 0

# Set Power Button to "Do Nothing"
powercfg -setacvalueindex SCHEME_CURRENT 4f971e89-eebd-4455-a8de-9e59040e7347 7648efa3-dd9c-4e3e-b566-50f929386280 0
powercfg -setdcvalueindex SCHEME_CURRENT 4f971e89-eebd-4455-a8de-9e59040e7347 7648efa3-dd9c-4e3e-b566-50f929386280 0

powercfg -SetActive SCHEME_CURRENT


# Get the directory of the script
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# Build the path to the sound file in the same directory as the script
$soundPath = Join-Path $scriptDir $SoundName

# Start volume keeper job for second sound
$volumeJob = Keep-Volume-At-Level
$mouseJob = Start-Mouse-Movement

# Play second sound
$player = New-Object System.Media.SoundPlayer
$player.SoundLocation = $soundPath
$player.PlaySync()  # PlaySync waits until the sound finishes playing

# Stop background jobs after sound ends
Stop-Job -Job $volumeJob, $mouseJob
Remove-Job -Job $volumeJob, $mouseJob

