# Simuler une touche du clavier pour empêcher le mode veille
function Prevent-Sleep-With-KeyPress {
    $shell = New-Object -ComObject WScript.Shell

    # Simuler l'appui sur la touche K
    $shell.SendKeys("{K}")

    # Attendre 20 secondes avant de simuler à nouveau
    Start-Sleep -Seconds 5

}

function Target-Comes {
Add-Type -AssemblyName System.Windows.Forms
$originalPOS = [System.Windows.Forms.Cursor]::Position.X
$o=New-Object -ComObject WScript.Shell

    while (1) {

        if ([Windows.Forms.Cursor]::Position.X -ne $originalPOS){
            Write-Host "Detected movement"
            $o.SendKeys("^{ESC}")  # Simulate WIN key
            Start-Sleep -Milliseconds 100  # Small delay to ensure WIN key is recognized
            $o.SendKeys("L")
        }
        else {
            Prevent-Sleep-With-KeyPress
        }
    }
}
#############################################################################################################################################


#############################################################################################################################################

#WPF Library for Playing Movie and some components
Add-Type -AssemblyName PresentationFramework

Add-Type -AssemblyName System.ComponentModel
#XAML File of WPF as windows for playing movie

[xml]$XAML = @"

<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="PowerShell Video Player" WindowState="Maximized" ResizeMode="NoResize" WindowStartupLocation="CenterScreen" >
        <MediaElement Stretch="Fill" Name="VideoPlayer" LoadedBehavior="Manual" UnloadedBehavior="Stop"  />
</Window>
"@


#Devide All Objects on XAML
$XAMLReader=(New-Object System.Xml.XmlNodeReader $XAML)
$Window=[Windows.Markup.XamlReader]::Load( $XAMLReader )


Write-Host "Version 14"
Write-Host "Waiting 30 sec"
Start-Sleep -Seconds 10
Write-Host "Waiting 20 sec"
Start-Sleep -Seconds 10
Write-Host "Waiting 10 sec"
Start-Sleep -Seconds 10

Write-Host "Payload Armed"

Target-Comes



