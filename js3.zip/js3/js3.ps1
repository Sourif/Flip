Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;

public class KeyboardInput
{
    [DllImport("user32.dll", SetLastError = true)]
    private static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, UIntPtr dwExtraInfo);

    private const int KEYEVENTF_EXTENDEDKEY = 0x0001;
    private const int KEYEVENTF_KEYUP = 0x0002;

    public static void SendWinL()
    {
        // Virtual key codes for WIN and L
        const byte VK_LWIN = 0x5B;
        const byte VK_L = 0x4C;

        // Press WIN key
        keybd_event(VK_LWIN, 0, KEYEVENTF_EXTENDEDKEY, UIntPtr.Zero);

        // Press L key
        keybd_event(VK_L, 0, KEYEVENTF_EXTENDEDKEY, UIntPtr.Zero);

        // Release L key
        keybd_event(VK_L, 0, KEYEVENTF_KEYUP, UIntPtr.Zero);

        // Release WIN key
        keybd_event(VK_LWIN, 0, KEYEVENTF_KEYUP, UIntPtr.Zero);
    }
}
"@

# Function to detect mouse movement and lock the computer
function Lock-On-Mouse-Move {
    Add-Type -AssemblyName System.Windows.Forms
    $originalPOS = [System.Windows.Forms.Cursor]::Position.X

    while ($true) {
        # Check if the mouse has moved
        if ([System.Windows.Forms.Cursor]::Position.X -ne $originalPOS) {
            Write-Host "Mouse movement detected. Locking computer..."
            # Simulate WIN + L key press to lock the computer
            [KeyboardInput]::SendWinL()
            break  # Exit the loop after locking
        }
        Start-Sleep -Seconds 1  # Check every second to reduce CPU usage
    }
}

# Run the function
Lock-On-Mouse-Move