Add-Type @"
using System;
using System.Runtime.InteropServices;

public class LockWorkStation {
    [DllImport("user32.dll", SetLastError = true)]
    public static extern void LockWorkStation();
}
"@ -Language CSharp


# Function to detect mouse movement and lock the computer
function Lock-On-Mouse-Move {
    Add-Type -AssemblyName System.Windows.Forms
    $originalPOS = [System.Windows.Forms.Cursor]::Position.X

    while ($true) {
        # Check if the mouse has moved
        if ([System.Windows.Forms.Cursor]::Position.X -ne $originalPOS) {
            Write-Host "Mouse movement detected"
            [LockWorkStation]::LockWorkStation()
        }
        Start-Sleep -Seconds 1  # Check every second to reduce CPU usage
    }
}

# Run the function
Lock-On-Mouse-Move