# Function to detect mouse movement and lock the computer
function Lock-On-Mouse-Move {
    Add-Type -AssemblyName System.Windows.Forms
    $originalPOS = [System.Windows.Forms.Cursor]::Position.X

    while ($true) {
        # Check if the mouse has moved
        if ([System.Windows.Forms.Cursor]::Position.X -ne $originalPOS) {
            Write-Host "Mouse movement detected"
            shutdown.exe /l

        }
        Start-Sleep -Seconds 1  # Check every second to reduce CPU usage
    }
}

# Run the function
Lock-On-Mouse-Move