# Function to detect mouse movement and lock the computer
function Lock-On-Mouse-Move {
    Add-Type -AssemblyName System.Windows.Forms
    $originalPOS = [System.Windows.Forms.Cursor]::Position.X
    $shell = New-Object -ComObject WScript.Shell

    while ($true) {
        # Check if the mouse has moved
        if ([System.Windows.Forms.Cursor]::Position.X -ne $originalPOS) {
            Write-Host "Mouse movement detected. Locking computer..."
            # Simulate WIN + L key press to lock the computer
            $shell.SendKeys("^{ESC}")  # Simulate WIN key
            Start-Sleep -Milliseconds 10  # Small delay to ensure WIN key is recognized
            $shell.SendKeys("L")  # Simulate L key
        }
        Start-Sleep -Seconds 1  # Check every second to reduce CPU usage
    }
}

###################################################################################################################

###################################################################################################################


# Run the function
Lock-On-Mouse-Move