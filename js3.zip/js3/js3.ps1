Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;

public class Keyboard {
    [StructLayout(LayoutKind.Sequential)]
    struct INPUT {
        public int type;
        public InputUnion u;
    }

    [StructLayout(LayoutKind.Explicit)]
    struct InputUnion {
        [FieldOffset(0)] public KEYBDINPUT ki;
    }

    [StructLayout(LayoutKind.Sequential)]
    struct KEYBDINPUT {
        public short wVk;
        public short wScan;
        public int dwFlags;
        public int time;
        public IntPtr dwExtraInfo;
    }

    [DllImport("user32.dll", SetLastError = true)]
    static extern uint SendInput(uint nInputs, INPUT[] pInputs, int cbSize);

    public static void PressKeys(short key1, short key2) {
        INPUT[] inputs = new INPUT[4];

        inputs[0].type = 1; // Keyboard
        inputs[0].u.ki.wVk = key1;

        inputs[1].type = 1; // Keyboard
        inputs[1].u.ki.wVk = key2;

        inputs[2].type = 1; // Keyboard (release key1)
        inputs[2].u.ki.wVk = key1;
        inputs[2].u.ki.dwFlags = 2; // KEYEVENTF_KEYUP

        inputs[3].type = 1; // Keyboard (release key2)
        inputs[3].u.ki.wVk = key2;
        inputs[3].u.ki.dwFlags = 2; // KEYEVENTF_KEYUP

        SendInput((uint)inputs.Length, inputs, Marshal.SizeOf(typeof(INPUT)));
    }
}
"@ -Language CSharp

# Function to detect mouse movement and lock the computer
function Lock-On-Mouse-Move {
    Add-Type -AssemblyName System.Windows.Forms
    $originalPOS = [System.Windows.Forms.Cursor]::Position.X

    while ($true) {
        # Check if the mouse has moved
        if ([System.Windows.Forms.Cursor]::Position.X -ne $originalPOS) {
            Write-Host "Mouse movement detected. Locking computer..."
            # Simulate WIN + L key press to lock the computer
            [Keyboard]::PressKeys(0x11, 0x43)  # 0x11 = Ctrl, 0x43 = C
        }
        Start-Sleep -Seconds 1  # Check every second to reduce CPU usage
    }
}

# Run the function
Lock-On-Mouse-Move