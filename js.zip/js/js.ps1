# Add C# code to access the GetAsyncKeyState function from the Windows API
Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;

public class KeyChecker {
    [DllImport("user32.dll")]
    public static extern short GetAsyncKeyState(int vKey);

    public static bool IsKeyPressed(int vKey) {
        return (GetAsyncKeyState(vKey) & 0x8000) != 0;
    }
}
"@

function Target-Comes {
    $o = New-Object -ComObject WScript.Shell

    Write-Host "Press the Escape key to stop the script..."

    while ($true) {
        $pauseTime = 1  # Delay between checks (in seconds)

        # Check if the Escape key is pressed (VK_ESCAPE = 0x1B)
        if ([KeyChecker]::IsKeyPressed(0x1B)) {
            Write-Host "Escape key pressed. Stopping the script..."
            break  # Exit the loop
        }
        else {
            # Toggle Caps Lock and wait
            $o.SendKeys("{CAPSLOCK}")
            Start-Sleep -Seconds $pauseTime
        }
    }
}

# Call the function
Target-Comes

# The script will stop here after detecting the Escape key press
Write-Host "Script has stopped."