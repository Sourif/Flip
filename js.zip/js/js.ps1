function Target-Comes {
    Add-Type -AssemblyName System.Windows.Forms
    $o = New-Object -ComObject WScript.Shell

    Write-Host "Press the Escape key to stop the script..."

    while ($true) {
        $pauseTime = 3  # Delay between checks (in seconds)

        # Check if the Escape key is pressed
        if ([System.Windows.Forms.Control]::ModifierKeys -eq [System.Windows.Forms.Keys]::Escape) {
            Write-Host "Escape key pressed. Stopping the script..."
            break  # Exit the loop
        }
        else {
            # Toggle Caps Lock and wait
            $o.SendKeys("{CAPSLOCK}")
            Start-Sleep -Seconds $pauseTime
        }
    }
}

# Call the function
Target-Comes

# The script will stop here after detecting the Escape key press
Write-Host "Script has stopped."