param(
    [string]$SoundName = "ALT.wav"  # Default sound name
)

Function Set-Volume
{
    Param(
        [Parameter(Mandatory=$true)]
        [ValidateRange(0,100)]
        [Int]
        $volume
    )

    # Calculate number of key presses.
    $keyPresses = [Math]::Ceiling( $volume / 2 )

    # Create the Windows Shell object.
    $obj = New-Object -ComObject WScript.Shell

    # Set volume to zero.
    1..50 | ForEach-Object {  $obj.SendKeys( [char] 174 )  }

    # Set volume to specified level.
    for( $i = 0; $i -lt $keyPresses; $i++ )
    {
        $obj.SendKeys( [char] 175 )
    }
}

#############################################################################################################################################


#WPF Library for Playing Movie and some components
Add-Type -AssemblyName PresentationFramework

Add-Type -AssemblyName System.ComponentModel
#XAML File of WPF as windows for playing movie

# Get the directory of the script
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# Build the path to the sound file in the same directory as the script
$soundPath = Join-Path $scriptDir $SoundName


Set-Volume 50
# Play  sound
$player = New-Object System.Media.SoundPlayer
$player.SoundLocation = $soundPath
$player.PlaySync()  # PlaySync waits until the sound finishes playing


