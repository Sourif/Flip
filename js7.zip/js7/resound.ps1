# Change to the directory where SoundVolumeView.exe is located
cd "C:\Users\timeo\Documents\Flipper\Java\js_gouli\test_folder\"  # <-- change this to your actual path

# Enable the playback device named "Speakers"
.\SoundVolumeView.exe /Enable "Speakers"

# Set it as the default playback device
.\SoundVolumeView.exe /SetDefault "Speakers" 1
